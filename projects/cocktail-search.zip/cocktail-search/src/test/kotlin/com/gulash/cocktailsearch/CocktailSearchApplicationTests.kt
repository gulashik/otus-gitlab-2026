package com.gulash.cocktailsearch

import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.DynamicPropertyRegistry
import org.springframework.test.context.DynamicPropertySource
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.get
import org.testcontainers.containers.PostgreSQLContainer
import org.testcontainers.junit.jupiter.Container
import org.testcontainers.junit.jupiter.Testcontainers

@SpringBootTest
@AutoConfigureMockMvc
@Testcontainers
class CocktailSearchApplicationTests(
	@Autowired private val mockMvc: MockMvc,
	@Autowired private val jdbcTemplate: JdbcTemplate,
) {
	companion object {
		@Container
		@JvmStatic
		val postgres = PostgreSQLContainer<Nothing>("postgres:17.11-alpine3.24").apply {
			withDatabaseName("cocktail_catalog")
			withUsername("cocktail")
			withPassword("cocktail-local-only")
		}

		@DynamicPropertySource
		@JvmStatic
		fun databaseProperties(registry: DynamicPropertyRegistry) {
			registry.add("spring.datasource.url", postgres::getJdbcUrl)
			registry.add("spring.datasource.username", postgres::getUsername)
			registry.add("spring.datasource.password", postgres::getPassword)
		}
	}

	@Test
	fun healthEndpointReturnsOk() {
		mockMvc.get("/actuator/health")
			.andExpect {
				status { isOk() }
				jsonPath("$.status") { value("UP") }
			}
	}

	@Test
	fun catalogueMigrationsSeedTheExpectedOriginalRecords() {
		val cocktailCount = jdbcTemplate.queryForObject(
			"SELECT COUNT(*) FROM cocktails",
			Int::class.java,
		)
		val dryGinIngredient = jdbcTemplate.queryForObject(
			"""
				SELECT i.canonical_name
				FROM ingredient_aliases AS a
				JOIN ingredients AS i ON i.id = a.ingredient_id
				WHERE a.alias = 'dry gin'
			""".trimIndent(),
			String::class.java,
		)

		kotlin.test.assertEquals(3, cocktailCount)
		kotlin.test.assertEquals("gin", dryGinIngredient)
	}

	@Test
	fun `search ranks distinct ingredient matches then cocktail name`() {
		mockMvc.get("/api/cocktails/search") {
			param("ingredient", "gin")
			param("ingredient", "lemon juice")
		}
			.andExpect {
				status { isOk() }
				jsonPath("$.cocktails[0].name") { value("Amber Orchard") }
				jsonPath("$.cocktails[0].matchCount") { value(2) }
				jsonPath("$.cocktails[1].name") { value("Bitter Sunset") }
				jsonPath("$.cocktails[1].matchCount") { value(1) }
				jsonPath("$.cocktails[2].name") { value("Citrus Fizz") }
				jsonPath("$.cocktails[2].matchCount") { value(1) }
			}
	}

	@Test
	fun `search resolves aliases and reports the canonical ingredient once`() {
		mockMvc.get("/api/cocktails/search") {
			param("ingredient", " dry gin ")
			param("ingredient", "GIN")
		}
			.andExpect {
				status { isOk() }
				jsonPath("$.recognizedIngredients[0]") { value("gin") }
				jsonPath("$.cocktails[0].matchedIngredients[0]") { value("gin") }
				jsonPath("$.cocktails[0].totalIngredientCount") { value(3) }
			}
	}

	@Test
	fun `unknown non blank ingredient is a valid empty search`() {
		mockMvc.get("/api/cocktails/search") { param("ingredient", "  Moon   dust ") }
			.andExpect {
				status { isOk() }
				jsonPath("$.recognizedIngredients") { isEmpty() }
				jsonPath("$.unrecognizedIngredients[0]") { value("moon dust") }
				jsonPath("$.cocktails") { isEmpty() }
			}
	}

	@Test
	fun `missing or blank ingredients return a JSON bad request`() {
		mockMvc.get("/api/cocktails/search")
			.andExpect {
				status { isBadRequest() }
				jsonPath("$.error") { value("Provide at least one non-blank ingredient parameter.") }
			}

		mockMvc.get("/api/cocktails/search") { param("ingredient", "   ", "\t") }
			.andExpect {
				status { isBadRequest() }
				jsonPath("$.error") { exists() }
			}
	}
}
