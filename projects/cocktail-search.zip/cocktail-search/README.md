# cocktail-search

A Kotlin and Spring Boot application that will search cocktail recipes by ingredient. 

Run test

```bash
./gradlew test
```

Start the local PostgreSQL service before running the application 

```bash
podman compose up -d postgres
podman compose ps
```

Start the service

```bash
SERVER_PORT=8081 ./gradlew bootRun
```

In another terminal, verify that it is ready:

```bash
curl --fail --silent --show-error http://localhost:8081/actuator/health
```
The response contains `{"status":"UP"}` and has HTTP status 200 when the  service is ready.

Inspect the records without installing `psql` on macOS:

```bash
podman compose exec postgres psql -U cocktail -d cocktail_catalog \
  -c 'SELECT name FROM cocktails ORDER BY name;'
```

The PostgreSQL connection uses the following variables:

| Variable      | Local default         |
|---------------|-----------------------|
| `DB_HOST`     | `localhost`           |
| `DB_PORT`     | `5432`                |
| `DB_NAME`     | `cocktail_catalog`    |
| `DB_USER`     | `cocktail`            |
| `DB_PASSWORD` | `cocktail-local-only` |

