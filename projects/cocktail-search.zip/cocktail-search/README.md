# cocktail-search

A Kotlin and Spring Boot application that will search cocktail recipes by ingredient. 

Run test

```bash
./gradlew test
```

Start the local PostgreSQL service before running the application 

```bash
podman compose up -d postgres
podman compose ps
```

Start the service

```bash
SERVER_PORT=8081 ./gradlew bootRun
```

In another terminal, verify that it is ready:

```bash
curl --fail --silent --show-error http://localhost:8081/actuator/health
```
The response contains `{"status":"UP"}` and has HTTP status 200 when the  service is ready.

## Ingredient search API

`GET /api/cocktails/search` accepts one or more repeated `ingredient` query parameters. 
Results are ordered by the number of distinct matched ingredients (descending), then cocktail name (ascending).

```bash
curl --get --silent --show-error http://localhost:8081/api/cocktails/search \
  --data-urlencode 'ingredient=dry gin' \
  --data-urlencode 'ingredient=lemon juice'
```

The response contains canonical recognized ingredients, normalized unknown
ingredients, and each matching recipe. For the seeded catalogue it begins like:

```json
{
  "recognizedIngredients": ["gin", "lemon juice"],
  "unrecognizedIngredients": [],
  "cocktails": [
    {
      "name": "Amber Orchard",
      "matchedIngredients": ["gin", "lemon juice"],
      "matchCount": 2,
      "totalIngredientCount": 3
    }
  ]
}
```

An unknown non-blank value is a valid search and returns HTTP 200 with an empty `cocktails` list and that normalized value in `unrecognizedIngredients`.
Omitting `ingredient`, or supplying only blank values, returns HTTP 400:

```json
{"error":"Provide at least one non-blank ingredient parameter."}
```

Inspect the records without installing `psql`:

```bash
podman compose exec postgres psql -U cocktail -d cocktail_catalog \
  -c 'SELECT name FROM cocktails ORDER BY name;'
```

The PostgreSQL connection uses the following variables:

| Variable      | Local default         |
|---------------|-----------------------|
| `DB_HOST`     | `localhost`           |
| `DB_PORT`     | `5432`                |
| `DB_NAME`     | `cocktail_catalog`    |
| `DB_USER`     | `cocktail`            |
| `DB_PASSWORD` | `cocktail-local-only` |

